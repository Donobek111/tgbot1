import os
import io
import json
import datetime
import logging
import base64
import tempfile
import requests
import asyncio
import aiohttp
import urllib.parse
from io import BytesIO
from typing import Dict, Optional

# aiogram 3.x
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import (
    Message,
    ReplyKeyboardMarkup,
    KeyboardButton,
    BufferedInputFile,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    PreCheckoutQuery,
    LabeledPrice,
)
from aiogram.filters import Command

# python-pptx
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

# ---------------------------
# CONFIG (вставь свои токены сюда или используй переменные окружения)
# ---------------------------
BOT_TOKEN = "7816366790:AAF3QQ6T3-Rt7UMFbxOGs8IYYSEt-8PrH3c"
OPENROUTER_API_KEY = "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"

# Для Telegram Stars НЕ НУЖЕН provider_token — оставляем пустым при отправке инвойса.
# (если в будущем нужно подключить внешний провайдер для других валют, добавь токен сюда)
PROVIDER_TOKEN = ""  # специально оставляем пустым для Stars (currency="XTR")

# Канал для проверки подписки
CHANNEL_USERNAME = "@xxsintsite"

# Владелец / admin
OWNER_ID = 1576570110

# ---------------------------
# LOGGING
# ---------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------
# BOT / DISPATCHER / ROUTER
# ---------------------------
bot = Bot(token="7816366790:AAF3QQ6T3-Rt7UMFbxOGs8IYYSEt-8PrH3c")
dp = Dispatcher()
router = Router()

# ---------------------------
# STORAGE (локальные json)
# ---------------------------
DATA_FILE = "users.json"
CHAT_MEM_FILE = "chat_mem.json"


def load_json(path):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning("Не получилось загрузить %s: %s", path, e)
    return {}


def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error("Ошибка сохранения %s: %s", path, e)


users = load_json(DATA_FILE)
chat_mem = load_json(CHAT_MEM_FILE)

# ---------------------------
# TEMP STATE (не сохраняется в users.json)
# ---------------------------
site_drafts: Dict[str, dict] = {}
presentation_state: Dict[str, str] = {}  # {user_id: chosen_color}
image_state: Dict[str, str] = {}
mode_map: Dict[str, str] = {}  # simple in-memory mode per user

# ---------------------------
# DEFAULTS / LIMITS
# ---------------------------
DEFAULT_BASE = {"site": 3, "image": 3, "presentation": 3}

# ---------------------------
# HELPERS: users / modes / limits
# ---------------------------
def ensure_user(user_id: str):
    today = str(datetime.date.today())
    if user_id not in users:
        users[user_id] = {
            "daily_limit_base": DEFAULT_BASE.copy(),
            "used_today": {"site": 0, "image": 0, "presentation": 0},
            "total_sites": 0,
            "total_images": 0,
            "total_presentations": 0,
            "referrals": 0,
            "joined": today,
            "last_reset": today,
        }
        save_json(DATA_FILE, users)


def reset_if_new_day(user_id: str):
    today = str(datetime.date.today())
    u = users.get(user_id)
    if not u:
        return
    if u.get("last_reset") != today:
        u["used_today"] = {"site": 0, "image": 0, "presentation": 0}
        u["last_reset"] = today
        save_json(DATA_FILE, users)


def set_mode(user_id: str, mode: str):
    mode_map[user_id] = mode


def get_mode(user_id: str):
    return mode_map.get(user_id, "menu")


# ИЗМЕНЕНИЕ: Логика user_limits обновлена
def user_limits(user_id: str):
    """Возвращает текущие лимиты с учётом рефералов: базовый + referrals"""
    u = users.get(user_id)
    if not u:
        return DEFAULT_BASE.copy()

    # Проверка на Владельца ИЛИ VIP-статус
    is_owner = False
    try:
        if int(user_id) == OWNER_ID:
            is_owner = True
    except Exception:
        pass

    if is_owner or u.get("is_vip") == True:
        return {"site": float("inf"), "image": float("inf"), "presentation": float("inf")}

    # Обычная логика для остальных
    refs = u.get("referrals", 0) or 0
    base = u.get("daily_limit_base", DEFAULT_BASE)
    if not isinstance(base, dict):
        base = DEFAULT_BASE.copy()

    return {k: base.get(k, DEFAULT_BASE[k]) + refs for k in DEFAULT_BASE.keys()}

# ---------------------------
# OpenRouter helpers (chat)
# ---------------------------
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"


def ask_openrouter_messages(messages):
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {"model": "gpt-4o-mini", "messages": messages}
    try:
        r = requests.post(OPENROUTER_URL, headers=headers, json=payload, timeout=60)
        r.raise_for_status()
        resp = r.json()
        try:
            return resp["choices"][0]["message"]["content"]
        except Exception:
            if isinstance(resp, dict):
                for v in resp.values():
                    if isinstance(v, str):
                        return v
        raise RuntimeError("OpenRouter returned unexpected response")
    except Exception as e:
        logger.exception("OpenRouter request failed: %s", e)
        raise


def ask_openrouter_with_image(user_text, image_path):
    with open(image_path, "rb") as f:
        b = f.read()
    img_b64 = base64.b64encode(b).decode("utf-8")
    headers = {"Authorization": f"Bearer {OPENROUTER_API_KEY}", "Content-Type": "application/json"}
    content = [{"type": "text", "text": user_text}, {"type": "image_url", "image_url": f"data:image/jpeg;base64,{img_b64}"}]
    payload = {"model": "gpt-4o-mini", "messages": [{"role": "user", "content": content}]}
    r = requests.post(OPENROUTER_URL, headers=headers, json=payload, timeout=120)
    r.raise_for_status()
    resp = r.json()
    try:
        return resp["choices"][0]["message"]["content"]
    except Exception:
        raise RuntimeError("OpenRouter (image) returned unexpected response")


from aiogram.filters import Command

# === VIP-КОМАНДЫ ===
@router.message(Command("vip"))
async def cmd_vip(message: Message):
    """Выдаёт VIP-доступ пользователю навсегда"""
    if message.from_user.id != OWNER_ID:
        await message.answer("❌ Только владелец может выдавать VIP-доступ.")
        return
    parts = (message.text or "").split()
    if len(parts) < 2:
        await message.answer("Использование: /vip <user_id>")
        return

    target_id = parts[1].strip()
    ensure_user(target_id)
    users[target_id]["is_vip"] = True # ИЗМЕНЕНИЕ: Установка флага
    save_json(DATA_FILE, users)
    await message.answer(f"✅ Пользователь {target_id} получил VIP-доступ навсегда.")

@router.message(Command("unvip"))
async def cmd_unvip(message: Message):
    """Отменяет VIP-доступ"""
    if message.from_user.id != OWNER_ID:
        await message.answer("❌ Только владелец может снимать VIP-доступ.")
        return
    parts = (message.text or "").split()
    if len(parts) < 2:
        await message.answer("Использование: /unvip <user_id>")
        return

    target_id = parts[1].strip()
    if target_id in users and users[target_id].get("is_vip"):
        users[target_id].pop("is_vip") # ИЗМЕНЕНИЕ: Удаление флага
        save_json(DATA_FILE, users)
        await message.answer(f"🟡 VIP-доступ снят у пользователя {target_id}.")
    else:
        await message.answer("ℹ️ Этот пользователь не был VIP.")

# ---------------------------
# Pollinations: простая генерация изображения через image.pollinations.ai
# ---------------------------
async def generate_image_pollinations(prompt_text: str, image_url: str = None) -> Optional[bytes]:
    """
    Использует публичный endpoint Pollinations: https://image.pollinations.ai/prompt/{urlencoded prompt}
    Возвращает байты изображения или None.
    """
    try:
        if not prompt_text:
            raise ValueError("Empty prompt")
        q = urllib.parse.quote(prompt_text)
        endpoint = f"https://image.pollinations.ai/prompt/{q}"
        async with aiohttp.ClientSession() as session:
            async with session.get(endpoint, timeout=120) as resp:
                if resp.status == 200:
                    return await resp.read()
                else:
                    text = await resp.text()
                    logger.error("Pollinations returned status %s: %s", resp.status, text[:200])
                    return None
    except Exception as e:
        logger.exception("Ошибка generate_image_pollinations: %s", e)
        return None


async def fetch_image_bytes(url: str) -> Optional[bytes]:
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=60) as resp:
                if resp.status == 200:
                    return await resp.read()
                else:
                    logger.warning("fetch_image_bytes: status %s for %s", resp.status, url)
                    return None
    except Exception as e:
        logger.exception("fetch_image_bytes error: %s", e)
        return None

# ---------------------------
# UI helpers
# ---------------------------
# ИЗМЕНЕНИЕ: Добавлена кнопка "VIP Пользователи"
def main_menu() -> ReplyKeyboardMarkup:
    kb = [
        [KeyboardButton(text="💬 Чат с ИИ"), KeyboardButton(text="🌐 Создать сайт")],
        [KeyboardButton(text="🖼️ Создать изображение"), KeyboardButton(text="📊 Создать презентацию")],
        [KeyboardButton(text="💖 Поддержать автора"), KeyboardButton(text="🚀 Лимит")],
        [KeyboardButton(text="📊 Статистика"), KeyboardButton(text="🤝 Пригласить друга")],
        [KeyboardButton(text="ℹ️ Помощь"), KeyboardButton(text="👑 VIP Пользователи")],
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True, input_field_placeholder="Выбирай👇")


def exit_keyboard() -> ReplyKeyboardMarkup:
    kb = [[KeyboardButton(text="Выйти в меню")], [KeyboardButton(text="❌ Отменить")]]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True, input_field_placeholder="Нажми Выйти в меню")


def subscribe_inline_markup() -> InlineKeyboardMarkup:
    channel = CHANNEL_USERNAME or ""
    channel_for_url = channel.lstrip("@") if isinstance(channel, str) else ""
    url = f"https://t.me/{channel_for_url}" if channel_for_url else "https://t.me/"
    ik = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Подписаться на канал", url=url)],
        [InlineKeyboardButton(text="Проверить подписку", callback_data="check_sub")]
    ])
    return ik

# ---------------------------
# Subscription check helper
# ---------------------------
async def user_is_subscribed(user_id: int) -> bool:
    """
    Проверяет, является ли пользователь участником CHANNEL_USERNAME.
    """
    if not CHANNEL_USERNAME:
        return True
    try:
        chat_member = await bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        status = getattr(chat_member, "status", None)
        return status in ("member", "creator", "administrator")
    except Exception as e:
        logger.info("subscribe check failed (treat as not subscribed): %s", e)
        return False


async def ensure_subscribed_or_prompt(message: Message) -> bool:
    uid = message.from_user.id
    ok = await user_is_subscribed(uid)
    if ok:
        return True
    await message.answer(
        "📢 Чтобы использовать бота, подпишитесь на канал и нажмите «Проверить подписку».",
        reply_markup=subscribe_inline_markup()
    )
    return False

# ---------------------------
# Presentation generator (pptx in-memory)
# ---------------------------
def create_presentation_bytes(topic: str, slides: list, style: str = "dark") -> bytes:
    prs = Presentation()
    color_schemes = {
        "dark": {"bg": RGBColor(12, 12, 12), "card": RGBColor(28, 28, 28), "title": RGBColor(255, 255, 255), "text": RGBColor(220, 220, 220)},
        "neon": {"bg": RGBColor(8, 8, 18), "card": RGBColor(20, 22, 36), "title": RGBColor(0, 255, 170), "text": RGBColor(200, 255, 230)},
        "minimal": {"bg": RGBColor(250, 250, 250), "card": RGBColor(255, 255, 255), "title": RGBColor(20, 20, 20), "text": RGBColor(50, 50, 50)},
        "purple": {"bg": RGBColor(45, 20, 70), "card": RGBColor(75, 40, 120), "title": RGBColor(255, 255, 255), "text": RGBColor(235, 225, 255)},
        "blue": {"bg": RGBColor(14, 34, 72), "card": RGBColor(32, 58, 110), "title": RGBColor(255, 255, 255), "text": RGBColor(220, 235, 255)},
    }
    if style not in color_schemes:
        style = "dark"
    pal = color_schemes[style]

    def set_slide_bg(slide, color: RGBColor):
        fill = slide.background.fill
        fill.solid()
        fill.fore_color.rgb = color

    title_slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(title_slide, pal["bg"])
    title_box = title_slide.shapes.add_textbox(Inches(0.6), Inches(2.0), Inches(9.0), Inches(1.6))
    tf = title_box.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.text = topic
    p.font.size = Pt(44)
    p.font.bold = True
    p.alignment = PP_ALIGN.CENTER
    p.font.color.rgb = pal["title"]

    subtitle = title_slide.shapes.add_textbox(Inches(0.6), Inches(3.2), Inches(9.0), Inches(0.8))
    stf = subtitle.text_frame
    stf.clear()
    sp = stf.paragraphs[0]
    sp.text = f"Generated by XXSINT • {datetime.date.today().isoformat()}"
    sp.font.size = Pt(12)
    sp.font.color.rgb = pal["text"]
    sp.alignment = PP_ALIGN.CENTER

    for s in slides:
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        set_slide_bg(slide, pal["bg"])
        left = Inches(0.7)
        top = Inches(0.9)
        width = Inches(8.2)
        height = Inches(5.2)
        try:
            shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        except Exception:
            shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)

        fill = shape.fill
        fill.solid()
        fill.fore_color.rgb = pal["card"]
        try:
            shape.line.fill.background()
        except Exception:
            pass

        title_tf = shape.text_frame
        title_tf.clear()
        title_p = title_tf.paragraphs[0]
        title_p.text = s.get("title", "")
        title_p.font.size = Pt(28)
        title_p.font.bold = True
        title_p.alignment = PP_ALIGN.LEFT
        title_p.font.color.rgb = pal["title"]

        paragraphs = []
        text_content = s.get("text", "")
        if "\n" in text_content:
            paragraphs = [ln.strip() for ln in text_content.splitlines() if ln.strip()]
        else:
            split_sent = [p.strip() for p in text_content.replace("  ", " ").split(". ") if p.strip()]
            paragraphs = split_sent

        for idx, para in enumerate(paragraphs):
            pbody = title_tf.add_paragraph()
            pbody.text = para if para.endswith(".") else (para + ".")
            pbody.font.size = Pt(14)
            pbody.font.color.rgb = pal["text"]
            pbody.space_before = Pt(6)
            pbody.alignment = PP_ALIGN.LEFT

        foot = title_tf.add_paragraph()
        foot.text = "✨ Created by XXSINT bot"
        foot.font.size = Pt(9)
        foot.font.color.rgb = pal["text"]
        foot.alignment = PP_ALIGN.RIGHT

    buf = BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf.getvalue()

# ---------------------------
# HANDLERS
# ---------------------------
@router.message(Command("start"))
async def cmd_start(message: Message):
    user_id = str(message.from_user.id)
    ensure_user(user_id)

    # referral handling
    args = (message.text or "").split()
    if len(args) > 1:
        ref = args[1]
        if ref != user_id and ref in users:
            users[ref]["referrals"] = users[ref].get("referrals", 0) + 1
            save_json(DATA_FILE, users)
            try:
                await bot.send_message(int(ref), "🎉 По вашей ссылке зарегистрировался новый пользователь — +1 к лимитам!")
            except Exception:
                pass

    # require subscription at start
    if not await user_is_subscribed(message.from_user.id):
        await message.answer(
            f"👋 Привет! Это 🤖 *XXSINT bot* — твой помощник для ИИ, сайтов и идей.\n\nПеред началом подпишись на наш канал — это нужно для работы бота.",
            parse_mode="Markdown",
            reply_markup=subscribe_inline_markup()
        )
        return

    await message.answer(f"👋 Привет! Это 🤖 *XXSINT bot* — твой помощник для ИИ, сайтов и идей.\nВыбирай, что хочешь сделать 👇", parse_mode="Markdown", reply_markup=main_menu())


@router.callback_query(F.data == "check_sub")
async def cb_check_sub(call):
    uid = call.from_user.id
    ok = await user_is_subscribed(uid)
    if ok:
        ensure_user(str(uid))
        try:
            await call.message.edit_text("✅ Подписка подтверждена! Можешь пользоваться ботом.", reply_markup=None)
        except Exception:
            pass
        await call.message.answer("Меню:", reply_markup=main_menu())
        await call.answer("Проверка пройдена ✅")
    else:
        await call.answer("Похоже, вы ещё не подписались.", show_alert=True)
        await call.message.answer("Вы всё ещё не подписаны — подпишитесь и нажмите «Проверить подписку» снова.", reply_markup=subscribe_inline_markup())


@router.message(F.text == "Выйти в меню")
async def text_exit_to_menu(message: Message):
    user_id = str(message.from_user.id)
    set_mode(user_id, "menu")
    await message.answer("🏠 Вернулся в меню.", reply_markup=main_menu())


@router.message(F.text == "❌ Отменить")
async def text_cancel(message: Message):
    user_id = str(message.from_user.id)
    set_mode(user_id, "menu")
    await message.answer("Отменено.", reply_markup=main_menu())


# Menu handlers (each checks subscription)
@router.message(F.text == "💬 Чат с ИИ")
async def btn_chat(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    ensure_user(user_id)
    set_mode(user_id, "chat")
    chat_mem.setdefault(user_id, [])
    save_json(CHAT_MEM_FILE, chat_mem)
    await message.answer("💬 Режим чата включён. Отправь текст или фото. Чтобы выйти — нажми «Выйти в меню».", reply_markup=exit_keyboard())


@router.message(F.text == "🌐 Создать сайт")
async def btn_create_site(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    ensure_user(user_id)
    reset_if_new_day(user_id)
    limits = user_limits(user_id)
    used = users[user_id].get("used_today", {"site": 0, "image": 0, "presentation": 0})
    if used.get("site", 0) >= limits["site"]:
        await message.answer("🚫 Лимит сайтов на сегодня исчерпан. Пригласи друга, чтобы получить +1.", reply_markup=main_menu())
        return
    set_mode(user_id, "site_step_type")
    await message.answer(
        "📝 Давай создадим сайт. Сначала — выбери тип (напиши цифру}:\n"
        "1 — Визитка\n2 — Блог\n3 — Лендинг\n4 — Магазин\n5 — Портфолио\n6 — Резюме\n7 — Новости\n8 — Обучение\n\nЧтобы отменить — нажми «Выйти в меню».",
        reply_markup=exit_keyboard(),
    )


@router.message(F.text == "🖼️ Создать изображение")
async def btn_create_image(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    ensure_user(user_id)
    reset_if_new_day(user_id)
    limits = user_limits(user_id)
    used = users[user_id].get("used_today", {"site": 0, "image": 0, "presentation": 0})
    if used.get("image", 0) >= (limits["image"] if limits["image"] != float("inf") else 1e18):
        await message.answer("🚫 Лимит изображений на сегодня исчерпан. Пригласи друга, чтобы получить +1.", reply_markup=main_menu())
        return
    set_mode(user_id, "image_prompt")
    await message.answer("🎨 Введи описание для картинки (например: космичный кот в очках). Чтобы отменить — нажми «Выйти в меню».", reply_markup=exit_keyboard())


# ---------- Presentation flow: show color choices ----------
@router.message(F.text == "📊 Создать презентацию")
async def btn_create_presentation(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    ensure_user(user_id)
    reset_if_new_day(user_id)
    limits = user_limits(user_id)
    used = users[user_id].get("used_today", {"site": 0, "image": 0, "presentation": 0})
    if used.get("presentation", 0) >= (limits["presentation"] if limits["presentation"] != float("inf") else 1e18):
        await message.answer("🚫 Лимит презентаций на сегодня исчерпан. Пригласи друга, чтобы получить +1.", reply_markup=main_menu())
        return

    ik = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🖤 Тёмная (Dark)", callback_data="pres_color:dark"),
         InlineKeyboardButton(text="⚡ Неон (Neon)", callback_data="pres_color:neon")],
        [InlineKeyboardButton(text="⚪ Минимализм (Minimal)", callback_data="pres_color:minimal"),
         InlineKeyboardButton(text="💜 Фиолетовая (Purple)", callback_data="pres_color:purple")],
        [InlineKeyboardButton(text="🔵 Голубая (Blue)", callback_data="pres_color:blue")],
        [InlineKeyboardButton(text="Выйти в меню", callback_data="pres_color:exit")]
    ])
    set_mode(user_id, "presentation_choose_color")
    await message.answer("🎨 Выбери цветовую тему презентации:", reply_markup=ik)


@router.callback_query(F.data.startswith("pres_color:"))
async def cb_pres_color(call):
    uid = str(call.from_user.id)
    data = call.data or ""
    color = data.split(":", 1)[1] if ":" in data else ""
    if color == "exit":
        set_mode(uid, "menu")
        try:
            await call.message.edit_text("Отменено. Возвращаю в меню.", reply_markup=None)
        except Exception:
            pass
        await call.message.answer("🏠 Меню:", reply_markup=main_menu())
        await call.answer()
        return

    if color not in ("dark", "neon", "minimal", "purple", "blue"):
        await call.answer("Неизвестная тему.", show_alert=True)
        return

    presentation_state[uid] = color
    set_mode(uid, "presentation_wait_topic")
    try:
        await call.message.edit_text(f"Выбрана тема **{color}**. Введи тему презентации (коротко):", parse_mode="Markdown")
    except Exception:
        pass
    await call.answer()

# ---------------------------
# Изменённая часть: Поддержать автора (подменю, слова / звезды / выйти)
# ---------------------------
@router.message(F.text == "💖 Поддержать автора")
async def btn_support(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    set_mode(user_id, "support_menu")
    ik = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💬 Поддержать словами", callback_data="support:words")],
        [InlineKeyboardButton(text="⭐ Поддержать звёздами", callback_data="support:stars")],
        [InlineKeyboardButton(text="⬅️ Выйти в меню", callback_data="support:back")]
    ])
    await message.answer("💖 Выберите способ поддержки автора:", reply_markup=ik)


@router.callback_query(F.data.startswith("support:"))
async def cb_support_menu(call):
    data = call.data or ""
    uid = str(call.from_user.id)
    action = data.split(":", 1)[1] if ":" in data else ""
    if action == "words":
        set_mode(uid, "support_write")
        try:
            await call.message.edit_text("✍️ Напишите короткое сообщение автору (оно будет отправлено).", reply_markup=None)
        except Exception:
            pass
        await call.message.answer("Напишите сообщение автору. Чтобы отменить — нажмите «Выйти в меню».", reply_markup=exit_keyboard())
        await call.answer()
        return

    if action == "stars":
        set_mode(uid, "support_wait_stars")
        try:
            await call.message.edit_text("⭐ Сколько звёзд вы хотите отправить? Введите число (например: 10).", reply_markup=None)
        except Exception:
            pass
        await call.message.answer("Введите количество звёзд (только число). Чтобы отменить — нажмите «Выйти в меню».", reply_markup=exit_keyboard())
        await call.answer()
        return

    if action == "back":
        set_mode(uid, "menu")
        try:
            await call.message.edit_text("🏠 Возвращаю в меню...", reply_markup=None)
        except Exception:
            pass
        await call.message.answer("Меню:", reply_markup=main_menu())
        await call.answer()
        return

    await call.answer("Неизвестная команда.", show_alert=True)

# ---------------------------
# Остальные меню + функционал (без изменений)
# ---------------------------
@router.message(F.text == "🚀 Лимит")
async def btn_limit(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    ensure_user(user_id)
    reset_if_new_day(user_id)
    limits = user_limits(user_id)
    used = users[user_id].get("used_today", {"site": 0, "image": 0, "presentation": 0})
    left = {}
    for k in limits:
        if limits[k] == float("inf"):
            left[k] = "∞"
        else:
            left[k] = max(0, limits[k] - used.get(k, 0))

    # ИЗМЕНЕНИЕ: Форматирование вывода для бесконечных лимитов
    site_limit_str = '∞' if limits['site'] == float('inf') else limits['site']
    image_limit_str = '∞' if limits['image'] == float('inf') else limits['image']
    pres_limit_str = '∞' if limits['presentation'] == float('inf') else limits['presentation']

    await message.answer(
        f"🚀 Сегодня ты можешь создать ещё:\n"
        f"• Сайты: {left['site']} из {site_limit_str}\n"
        f"• Изображения: {left['image']} из {image_limit_str}\n"
        f"• Презентации: {left['presentation']} из {pres_limit_str}\n",
        reply_markup=main_menu(),
    )


@router.message(F.text == "📊 Статистика")
async def btn_stats(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    ensure_user(user_id)
    reset_if_new_day(user_id)
    u = users[user_id]
    await message.answer(
        f"📊 Статистика:\n"
        f"• Всего создано сайтов: {u.get('total_sites',0)}\n"
        f"• Всего создано изображений: {u.get('total_images',0)}\n"
        f"• Всего создано презентаций: {u.get('total_presentations',0)}\n"
        f"• Создано сегодня: {u.get('used_today',{})}\n"
        f"• Рефералов: {u.get('referrals',0)}\n"
        f"• Дата регистрации: {u.get('joined')}",
        reply_markup=main_menu(),
    )


@router.message(F.text == "🤝 Пригласить друга")
async def btn_invite(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    user_id = str(message.from_user.id)
    try:
        me = await bot.get_me()
        bot_username = me.username if hasattr(me, "username") else None
    except Exception:
        bot_username = None
    if not bot_username:
        link = f"https://t.me/YourBot?start={user_id}"
    else:
        link = f"https://t.me/{bot_username}?start={user_id}"
    await message.answer(f"🤝 Поделись ссылкой:\n{link}\n\nЗа каждого нового — +1 к лимитам (всем трём функциям).", reply_markup=main_menu())


@router.message(F.text == "ℹ️ Помощь")
async def btn_help(message: Message):
    if not await ensure_subscribed_or_prompt(message):
        return
    await message.answer(
        "ℹ️ Помощь и контакты:\nПиши в поддержку: @xxsint\n\nКак опубликовать HTML: Netlify / Vercel / GitHub Pages.",
        reply_markup=main_menu(),
    )

# ИЗМЕНЕНИЕ: Новый обработчик для кнопки "VIP Пользователи"
@router.message(F.text == "👑 VIP Пользователи")
async def btn_vip_list(message: Message):
    user_id = message.from_user.id

    # Только владелец может видеть список
    if user_id != OWNER_ID:
        await message.answer("❌ Эта команда доступна только владельцу бота.", reply_markup=main_menu())
        return

    set_mode(str(user_id), "vip_list_view") # Устанавливаем режим для exit_keyboard

    vip_ids = []
    # Ищем VIP-пользователей в 'users'
    for uid, data in users.items():
        if data.get("is_vip") == True:
            vip_ids.append(f"`{uid}`") # Добавляем ID в список

    if not vip_ids:
        await message.answer("👑 Список VIP-пользователей пуст.", reply_markup=exit_keyboard())
        return

    vip_list_str = "\n".join(vip_ids)
    await message.answer(
        f"👑 Активные VIP-пользователи:\n\n{vip_list_str}",
        parse_mode="Markdown",
        reply_markup=exit_keyboard() # Используем стандартную клавиатуру выхода
    )

# Photo handler used only in chat mode
@router.message(F.photo)
async def handle_photo(message: Message):
    user_id = str(message.from_user.id)
    mode = get_mode(user_id)
    if mode != "chat":
        await message.answer("📸 Фото можно отправлять в режиме 'Чат с ИИ' (кнопка «💬 Чат с ИИ»).")
        return
    photo = message.photo[-1]
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as tmpf:
            tmp_path = tmpf.name
            try:
                f_info = await bot.get_file(photo.file_id)
                try:
                    await f_info.download(destination=tmp_path)
                except Exception:
                    try:
                        await bot.download_file(f_info.file_path, tmp_path)
                    except Exception:
                        await photo.download(destination=tmp_path)
            except Exception:
                try:
                    await photo.download(destination=tmp_path)
                except Exception as e:
                    raise RuntimeError(f"Не удалось скачать файл фото: {e}")
        caption = message.caption or "Опиши, что на изображении"
        await message.answer("🧠 Обрабатываю изображение...")
        try:
            reply = ask_openrouter_with_image(caption, tmp_path)
        except Exception as e:
            reply = f"⚠️ Ошибка при обращении к OpenRouter: {e}"
        chat_mem.setdefault(user_id, [])
        chat_mem[user_id] = chat_mem[user_id] + [{"role": "user", "content": caption}, {"role": "assistant", "content": reply}]
        if len(chat_mem[user_id]) > 100:
            chat_mem[user_id] = chat_mem[user_id][-100:]
        save_json(CHAT_MEM_FILE, chat_mem)
        await message.answer(reply, reply_markup=exit_keyboard())
    finally:
        if tmp_path:
            try:
                os.remove(tmp_path)
            except Exception:
                pass

# General text handler: chat flow + site creation flow + image + presentation + support
@router.message(F.text & ~F.via_bot)
async def all_text_handler(message: Message):
    user_id = str(message.from_user.id)
    ensure_user(user_id)
    mode = get_mode(user_id)
    text = (message.text or "").strip()

    if not text:
        return

    # If user is in support_wait_stars mode: handle numeric input and send invoice (Stars)
    if mode == "support_wait_stars":
        # Validate numeric input
        try:
            amount = int(text)
        except Exception:
            await message.answer("Пожалуйста, введите число (например: 10) или нажмите «Выйти в меню».", reply_markup=exit_keyboard())
            return

        if amount <= 0:
            await message.answer("Число должно быть положительным. Введите снова.", reply_markup=exit_keyboard())
            return

        # For Stars, provider_token is empty and currency="XTR"
        price_amount = int(amount)  # Оставляем как есть для Stars

        prices = [LabeledPrice(label=f"Stars x{amount}", amount=price_amount)]

        pay_kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=f"💳 Оплатить {amount} ⭐", pay=True)],
            [InlineKeyboardButton(text="⬅️ Выйти в меню", callback_data="support:back")]
        ])

        try:
            # provider_token intentionally empty for Stars
            await bot.send_invoice(
                chat_id=message.chat.id,
                title="Поддержка автора",
                description=f"Подарите {amount} звёзд автору — спасибо!",
                provider_token="",  # empty for Telegram Stars
                currency="XTR",
                prices=prices,
                payload=f"support_{message.from_user.id}_{amount}_stars",
                reply_markup=pay_kb
            )
            set_mode(user_id, "menu")
        except Exception as e:
            logger.exception("Ошибка при отправке инвойса: %s", e)
            await message.answer(f"⚠️ Не удалось отправить заявку на оплату: {e}", reply_markup=main_menu())
            set_mode(user_id, "menu")
        return

    # CHAT MODE
    if mode == "chat":
        chat_mem.setdefault(user_id, [])
        chat_mem[user_id].append({"role": "user", "content": text})
        if len(chat_mem[user_id]) > 100:
            chat_mem[user_id] = chat_mem[user_id][-100:]
        save_json(CHAT_MEM_FILE, chat_mem)

        thinking_msg = await message.answer("🧠 Думаю...", reply_markup=exit_keyboard())
        try:
            history = chat_mem[user_id]
            reply = ask_openrouter_messages(history)

            # Add assistant reply to memory
            chat_mem[user_id].append({"role": "assistant", "content": reply})
            save_json(CHAT_MEM_FILE, chat_mem)

            await thinking_msg.edit_text(reply, reply_markup=exit_keyboard())
        except Exception as e:
            logger.exception("Error in chat mode (OpenRouter): %s", e)
            await thinking_msg.edit_text(f"⚠️ Ошибка: {e}\n\nПопробуй ещё раз или выйди в меню.", reply_markup=exit_keyboard())
        return

    # SUPPORT WRITE MODE
    if mode == "support_write":
        try:
            await bot.send_message(OWNER_ID, f"💬 Новое сообщение поддержки от {message.from_user.id} ({message.from_user.full_name}):\n\n{text}")
            await message.answer("✅ Спасибо! Твоё сообщение отправлено автору.", reply_markup=main_menu())
        except Exception as e:
            logger.error("Failed to forward support message: %s", e)
            await message.answer("⚠️ Ошибка. Не удалось отправить сообщение.", reply_markup=main_menu())
        set_mode(user_id, "menu")
        return

    # SITE CREATION: Step 1 (Type)
    if mode == "site_step_type":
        site_drafts[user_id] = {"type": text}
        set_mode(user_id, "site_step_topic")
        await message.answer("📝 Тип принят. Теперь введи **тему** сайта (например: 'Ремонт квартир в Москве', 'Блог о котах'):", parse_mode="Markdown", reply_markup=exit_keyboard())
        return

    # SITE CREATION: Step 2 (Topic)
    if mode == "site_step_topic":
        if user_id not in site_drafts:
            await message.answer("Ошибка. Начните создание сайта заново из меню.", reply_markup=main_menu())
            set_mode(user_id, "menu")
            return
        site_drafts[user_id]["topic"] = text
        set_mode(user_id, "site_step_details")
        await message.answer("📝 Тема принята. Теперь введи **детали** (коротко опиши, что должно быть на сайте, контакты, особенности):", parse_mode="Markdown", reply_markup=exit_keyboard())
        return

    # SITE CREATION: Step 3 (Details & Generation)
    if mode == "site_step_details":
        if user_id not in site_drafts or "topic" not in site_drafts[user_id]:
            await message.answer("Ошибка. Начните создание сайта заново из меню.", reply_markup=main_menu())
            set_mode(user_id, "menu")
            return

        site_drafts[user_id]["details"] = text
        draft = site_drafts[user_id]
        set_mode(user_id, "menu") # Reset mode

        # Check limits (already checked, but good for safety)
        reset_if_new_day(user_id)
        limits = user_limits(user_id)
        used = users[user_id].get("used_today", {"site": 0})
        if used.get("site", 0) >= limits["site"]:
            await message.answer("🚫 Лимит сайтов на сегодня исчерпан.", reply_markup=main_menu())
            return

        thinking_msg = await message.answer("🌐 Генерирую HTML-сайт... (до 60 секунд)", reply_markup=main_menu())

        try:
            # Use OpenRouter to generate HTML
            prompt = (
                f"Создай ОДИН HTML-файл для сайта (только HTML, без объяснений). "
                f"Тема: {draft['topic']}. Тип: {draft['type']}. Детали: {draft['details']}. "
                f"Включи стили CSS в тег <style>. Не используй внешние JS или CSS. "
                f"Весь код должен быть в одном файле. Начни с <!DOCTYPE html>."
            )
            messages = [{"role": "system", "content": prompt}]

            html_content = ask_openrouter_messages(messages)

            # Clean up response
            if html_content.startswith("```html"):
                html_content = html_content[7:]
            if html_content.endswith("```"):
                html_content = html_content[:-3]
            html_content = html_content.strip()

            # Update stats
            users[user_id]["used_today"]["site"] = used.get("site", 0) + 1
            users[user_id]["total_sites"] = users[user_id].get("total_sites", 0) + 1
            save_json(DATA_FILE, users)

            # Send as file
            html_bytes = html_content.encode('utf-8')
            file = BufferedInputFile(html_bytes, filename=f"site_{user_id}.html")
            await message.answer_document(file, caption="✅ Готово! Вот твой HTML-сайт.")
            await thinking_msg.delete()

        except Exception as e:
            logger.exception("Error in site generation: %s", e)
            await thinking_msg.edit_text(f"⚠️ Ошибка генерации сайта: {e}", reply_markup=main_menu())

        if user_id in site_drafts:
            del site_drafts[user_id] # Clean up draft
        return

    # IMAGE PROMPT
    if mode == "image_prompt":
        set_mode(user_id, "menu") # Reset mode

        # Check limits
        reset_if_new_day(user_id)
        limits = user_limits(user_id)
        used = users[user_id].get("used_today", {"image": 0})
        if used.get("image", 0) >= (limits["image"] if limits["image"] != float("inf") else 1e18):
            await message.answer("🚫 Лимит изображений на сегодня исчерпан.", reply_markup=main_menu())
            return

        thinking_msg = await message.answer("🎨 Генерирую изображение... (Pollinations, до 60 сек)", reply_markup=main_menu())

        try:
            image_bytes = await generate_image_pollinations(text)
            if image_bytes:
                # Update stats
                users[user_id]["used_today"]["image"] = used.get("image", 0) + 1
                users[user_id]["total_images"] = users[user_id].get("total_images", 0) + 1
                save_json(DATA_FILE, users)

                file = BufferedInputFile(image_bytes, filename=f"image_{user_id}.jpg")
                await message.answer_photo(file, caption=f"🖼️ Изображение по запросу: {text}", reply_markup=main_menu())
                await thinking_msg.delete()
            else:
                await thinking_msg.edit_text("⚠️ Не удалось сгенерировать изображение (Pollinations вернул ошибку).", reply_markup=main_menu())

        except Exception as e:
            logger.exception("Error in image generation: %s", e)
            await thinking_msg.edit_text(f"⚠️ Ошибка генерации изображения: {e}", reply_markup=main_menu())
        return

    # PRESENTATION: Wait Topic
    if mode == "presentation_wait_topic":
        color_style = presentation_state.get(user_id, "dark") # Get saved color
        set_mode(user_id, "menu") # Reset mode

        # Check limits
        reset_if_new_day(user_id)
        limits = user_limits(user_id)
        used = users[user_id].get("used_today", {"presentation": 0})
        if used.get("presentation", 0) >= (limits["presentation"] if limits["presentation"] != float("inf") else 1e18):
            await message.answer("🚫 Лимит презентаций на сегодня исчерпан.", reply_markup=main_menu())
            return

        thinking_msg = await message.answer("📊 Генерирую структуру презентации... (Шаг 1/2)", reply_markup=main_menu())

        try:
            # Step 1: Generate slide content (JSON)
            prompt = (
                f"Создай контент для презентации на тему: '{text}'. "
                f"Нужно 5-7 слайдов (не считая титульного). "
                f"Ответ дай в виде JSON-массива, где каждый объект - это слайд: "
                f'[{{"title": "Название слайда 1", "text": "Текст слайда 1..."}}, {{"title": "Название слайда 2", "text": "Текст слайда 2..."}}]'
                f"Ответ должен быть ТОЛЬКО JSON, без вступлений."
            )
            messages = [{"role": "system", "content": prompt}]

            json_content_str = ask_openrouter_messages(messages)

            # Clean up JSON
            if json_content_str.startswith("```json"):
                json_content_str = json_content_str[7:]
            if json_content_str.endswith("```"):
                json_content_str = json_content_str[:-3]
            json_content_str = json_content_str.strip()

            slides_data = json.loads(json_content_str)
            if not isinstance(slides_data, list):
                raise ValueError("AI returned non-list JSON")

            await thinking_msg.edit_text("🎨 Собираю PPTX файл... (Шаг 2/2)")

            # Step 2: Create PPTX
            pptx_bytes = create_presentation_bytes(topic=text, slides=slides_data, style=color_style)

            # Update stats
            users[user_id]["used_today"]["presentation"] = used.get("presentation", 0) + 1
            users[user_id]["total_presentations"] = users[user_id].get("total_presentations", 0) + 1
            save_json(DATA_FILE, users)

            # Send file
            file = BufferedInputFile(pptx_bytes, filename=f"presentation_{user_id}.pptx")
            await message.answer_document(file, caption=f"✅ Готово! Презентация на тему: {text}", reply_markup=main_menu())
            await thinking_msg.delete()

        except json.JSONDecodeError:
            logger.error("Failed to parse JSON from OpenRouter: %s", json_content_str[:500])
            await thinking_msg.edit_text("⚠️ Ошибка: ИИ вернул некорректный JSON-формат. Попробуйте другую тему.", reply_markup=main_menu())
        except Exception as e:
            logger.exception("Error in presentation generation: %s", e)
            await thinking_msg.edit_text(f"⚠️ Ошибка генерации презентации: {e}", reply_markup=main_menu())

        if user_id in presentation_state:
            del presentation_state[user_id] # Clean up state
        return

    # Fallback: if in menu, show menu
    if mode == "menu":
        # Не отвечаем на кнопки меню, которые уже были обработаны выше
        known_buttons = [
            "💬 Чат с ИИ", "🌐 Создать сайт", "🖼️ Создать изображение", "📊 Создать презентацию",
            "💖 Поддержать автора", "🚀 Лимит", "📊 Статистика", "🤝 Пригласить друга", "ℹ️ Помощь",
            "👑 VIP Пользователи", "Выйти в меню", "❌ Отменить"
        ]
        if text not in known_buttons:
             await message.answer("Я не понял команду. Пожалуйста, используй кнопки меню 👇", reply_markup=main_menu())
    elif mode == "vip_list_view":
         await message.answer("Вы находитесь в меню просмотра VIP. Нажмите 'Выйти в меню'.", reply_markup=exit_keyboard())
    else:
        # Fallback for any unknown state
        await message.answer("Неопознанный режим. Возвращаю в меню.", reply_markup=main_menu())
        set_mode(user_id, "menu")
    return

# ---------------------------
# PAYMENT HANDLERS (for Stars)
# ---------------------------

# Handle PreCheckoutQuery (required)
@router.pre_checkout_query()
async def pre_checkout_handler(pre_checkout_query: PreCheckoutQuery):
    # We must answer within 10 seconds
    await bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)

# Handle successful payment
@router.message(F.successful_payment)
async def successful_payment_handler(message: Message):
    payment = message.successful_payment

    # Check if it was for Stars (currency="XTR")
    if payment and payment.currency == "XTR":
        amount = payment.total_amount

        await message.answer(f"⭐ Спасибо! Вы успешно отправили {amount} звёзд.", reply_markup=main_menu())

        # Notify owner
        try:
            await bot.send_message(OWNER_ID, f"🎉 Получена поддержка! {message.from_user.id} ({message.from_user.full_name}) отправил {amount} звёзд (XTR).")
        except Exception as e:
            logger.warning("Failed to notify owner about stars: %s", e)
    else:
        # Handle other currencies if added later
        await message.answer(f"Спасибо за оплату!", reply_markup=main_menu())

# ---------------------------
# MAIN (Start bot)
# ---------------------------
async def main():
    # Include the router in the dispatcher
    dp.include_router(router)

    # Ensure data is saved on shutdown
    try:
        logger.info("Bot starting...")
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
    finally:
        logger.info("Bot stopping...")
        save_json(DATA_FILE, users)
        save_json(CHAT_MEM_FILE, chat_mem)
        await bot.session.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by admin.")